#include <windows.h>
#include <stdio.h>

int txts = 0;

void check_file(const char *path, const char *file_name) {
    // Create the full path to the file
    char full_path[MAX_PATH];
    snprintf(full_path, sizeof(full_path), "%s\\%s", path, file_name);

    // the strrchr gets the last period and everything after including the last period is recorded into the ext variable 
    const char *ext = strrchr(file_name, '.');
    
    if (ext != NULL) {
        if (strcmp(ext, ".txt") == 0) {
	    txts++;
            printf("\n%s is a .txt file\n", full_path);
        }         // Add more conditions for other file extensions if needed
    } 
}

void search_directory(const char *path) {
    WIN32_FIND_DATA find_file_data;
    HANDLE hFind = INVALID_HANDLE_VALUE;

    char search_path[MAX_PATH];
    snprintf(search_path, sizeof(search_path), "%s\\*", path);

    // Start searching in the directory
    hFind = FindFirstFile(search_path, &find_file_data);

    if (hFind == INVALID_HANDLE_VALUE) {
        return;
    }

    // Store directories to process later
    char directories[MAX_PATH][MAX_PATH];
    int dir_count = 0;

    // Loop through the directory contents
    do {
        const char *file_name = find_file_data.cFileName;

        // Skip the '.' and '..' entries
        if (strcmp(file_name, ".") != 0 && strcmp(file_name, "..") != 0) {
            // If it's a file, check and print its extension
            if (!(find_file_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
                check_file(path, file_name);
            } else {
                // If it's a directory, store it to process later
                char new_path[MAX_PATH];
                snprintf(new_path, sizeof(new_path), "%s\\%s", path, file_name);
                snprintf(directories[dir_count], sizeof(directories[dir_count]), "%s", new_path);
                dir_count++;
            }
        }
    } while (FindNextFile(hFind, &find_file_data) != 0);

    // Close the search handle
    FindClose(hFind);

    // Process directories after all files are processed
    for (int i = 0; i < dir_count; i++) {
        search_directory(directories[i]);  // Recurse into subdirectories
    }
}

int main() {
    // Start searching from a directory (e.g., "C:\\Users")
    const char *start_path = "C:\\Users";
    search_directory(start_path);
    printf("\n%s NUMBER OF TXTS\n", txts);
    return 0;
}
